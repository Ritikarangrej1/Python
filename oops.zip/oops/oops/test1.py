class Person :

    def __init__(self,name,surname , emailid , year_of_birth):
        self.name1 = name
        self.surname = surname
        self.emailid = emailid
        self.year_of_birth = year_of_birth

ritika_var  = Person("ritika" , "rangrej" , "ritika@gmail.com" , 2000)
tejas = Person("tejas " ,"kumbar" , "tejas@gmail.com" , 2001)
vaibhav = Person("vaibhav" , "waghmare" , "vaibhav@gmail.com" , 2002)
print(ritika_var.name1)
print(tejas.name1)
print(vaibhav.name1)
print(type(tejas))