class Person :

    def __init__(ritika,name,surname , emailid , year_of_birth):
        ritika.name1 = name
        ritika.surname = surname
        ritika.emailid = emailid
        ritika.year_of_birth = year_of_birth

    def __init__(ritika,name,surname ):
        ritika.name1 = name
        ritika.surname = surname

    def age(ritika , curretn_year):
        return curretn_year - ritika.year_of_birth

tejas_var  = Person("tejas" , "kumbhar" , "tejas@gmail.com" , 1994)
ritika = Person("ritika " ,"rangrej" , "ritika@gmail.com" , 23424)
vaibhav = Person("vaibhav" , "waghmare" , "vaibhav@gmail.com" , 234242)
print(tejas_var.age(2022))

s = "ritika"
s.upper()