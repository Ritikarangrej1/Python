class person :

    def age(self, curretn_year , year_of_birth):
        return curretn_year - year_of_birth

    def email_id_input(self, email_id ):
        print("take and mail id form a person and print it " , email_id)

    def ask_name(self):
        name = input("tell me your name ")
        return name

    def ask_dob(self):
        dob = input("tell me your date of birth ")
        return dob

ritika = person()
tejas = person()
vaibhav = person()
madhu = person()
hitesh = person()

ritika.email_id_input("ritika@ineron.ai")
print(ritika.ask_name())

print(hitesh.ask_dob())





