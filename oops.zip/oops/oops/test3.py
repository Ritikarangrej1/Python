class Person :

    def __init__(tejas,name,surname , emailid , year_of_birth):
        tejas.name1 = name
        tejas.surname = surname
        tejas.emailid = emailid
        tejas.year_of_birth = year_of_birth

    def __init__(tejas,name,surname ):
        tejas.name1 = name
        tejas.surname = surname

    def age(tejas , curretn_year):
        return curretn_year

ritika  = Person("ritika" , "rangrej")
tejas = Person("tejas " ,"kumbhar" )
vaibhav = Person("vaibhav" , "waghmare" )
print(ritika.age(2022))

s = "tejas"
s.upper()