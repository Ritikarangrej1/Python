from utils.utill1 import person2

obj = person2("ritika " , "rangrej" , 345345)
print(obj.yob1)

class person1 :
    def __init__(self , name ,surname , yob):
        self._name1 = name
        self.__surname1 = surname
        self.yob1 = yob

ritika = person1("ritika" , "rangrej" , 1990)
print(ritika._name1)
print(ritika._person1__surname1)