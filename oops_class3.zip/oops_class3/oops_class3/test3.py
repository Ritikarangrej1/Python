class ineuron:
    def student(self):
        print("print the details of all the students")
    def achivers(self):
        print("print the list of all the achiver ")
    def hall_of_fame(self):
        print("print everyone form hall of fame ")

class ineuron_vision(ineuron):

    def student(self):
        print("these are the filters student list ")

iv =  ineuron_vision()
iv.student()

